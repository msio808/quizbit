#!/bin/bash

REQUIRED_PACKAGES=(
    "build-essential"
    "libpcre3-dev"
    "libssl-dev"
    "valgrind"
    "sqlite3"
    "cmake"
    "make"
)

is_installed() {
    dpkg -l | grep -qw "$1"
}

echo "Updating package list..."
sudo apt-get update

for PACKAGE in "${REQUIRED_PACKAGES[@]}"; do
    if is_installed "$PACKAGE"; then
        echo "$PACKAGE is already installed."
    else
        echo "$PACKAGE is not installed. Installing..."
        sudo apt-get install -y "$PACKAGE"
    fi
done

echo "All required packages are installed."
